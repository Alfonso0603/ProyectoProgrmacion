package controller;

import dao.*;
import model.*;

public class Main {

	public static void main(String[] args) {
		
		AventuraJuego juego = new AventuraJuego ();
		
		juego.mostrarJuego();
		

	}

}
