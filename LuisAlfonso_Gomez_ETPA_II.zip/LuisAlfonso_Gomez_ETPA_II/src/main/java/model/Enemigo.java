package model;

public class Enemigo extends Personaje {

	private String especie;

	public Enemigo(String nombre, int vida, int vidaMaxima, String especie) {
		super(nombre, vida, vidaMaxima);
		this.especie = especie;
		
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	@Override
	public String toString() {
		return "Enemigo [especie=" + especie + "]";
	}
	
	public void atacar(Personaje personaje, AtaqueEnemigo ataque) {
	    int danio = ataque.getDanio();
	    int vidaRestante = personaje.getVida() - danio;

	    if (vidaRestante < 0) {
	        vidaRestante = 0;
	    }

	    personaje.setVida(vidaRestante);

	    System.out.println(this.getNombre() + " usó " + ataque.getNombre() + " causando " + danio + " de daño a " + personaje.getNombre() + ". Vida restante del personaje: " + vidaRestante);
	}

	
	

}
