package model;

public class Personaje {
	
	private String nombre;
    private int vida;
    private int vidaMaxima;
    
	public Personaje(String nombre, int vida, int vidaMaxima) {
		this.nombre = nombre;
		this.vida = vida;
		this.vidaMaxima = vida;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}
	

	public int getVidaMaxima() {
		return vidaMaxima;
	}

	public void setVidaMaxima(int vidaMaxima) {
		this.vidaMaxima = vidaMaxima;
	}

	@Override
	public String toString() {
		return "Personaje [nombre=" + nombre + ", vida=" + vida + "]";
	}
	
	public void atacar(Enemigo enemigo, AtaquePersonaje ataque) {
	    int danio = ataque.getDanio();
	    int vidaRestante = enemigo.getVida() - danio;

	    if (vidaRestante < 0) {
	        vidaRestante = 0;
	    }

	    enemigo.setVida(vidaRestante);

	    System.out.println(this.getNombre() + " usó " + ataque.getNombre() + " causando " + danio + " de daño a " + enemigo.getNombre() + ". Vida restante del enemigo: " + vidaRestante);
	}

	
    
    
    
}
