package model;

import model.*;

public class Combate {
	
	public static int ejecutarCombates(Personaje personaje) {
        int combatesGanados = 0;

        Enemigo enemigo1 = new Enemigo("Megalodón", 60, 60, "Tiburón");
        Enemigo enemigo2 = new Enemigo("Piratas", 50, 50, "Humanos hostiles");

        if (luchar(personaje, enemigo1)) combatesGanados++;
        if (luchar(personaje, enemigo2)) combatesGanados++;

        return combatesGanados;
    }

    private static boolean luchar(Personaje personaje, Enemigo enemigo) {
        System.out.println("\nEnfrentando a " + enemigo.getNombre());

        AtaquePersonaje ataqueP = new AtaquePersonaje("Arpón", 20, "Perforante");
        AtaqueEnemigo ataqueE = new AtaqueEnemigo("Mordida", 15, "Físico");

        while (personaje.getVida() > 0 && enemigo.getVida() > 0) {
            personaje.atacar(enemigo, ataqueP);
            if (enemigo.getVida() > 0) enemigo.atacar(personaje, ataqueE);
        }

        boolean victoria = personaje.getVida() > 0;

        if (victoria) {
            System.out.println("¡Ganaste el combate!");
        } else {
            System.out.println("Has sido derrotado...");
        }

        return victoria;
    }

}
