package model;

public class Usuario {

	
	private int id_Usario;
	private String nombreUsuario;
	private String contrasena;
	private int puntuacion;
	
	public Usuario () {
		
	}
	
	
	public Usuario(int id_Usario, String nombreUsuario, String contrasena, int puntuacion) {
		this.id_Usario = id_Usario;
		this.nombreUsuario = nombreUsuario;
		this.contrasena = contrasena;
		this.puntuacion = puntuacion;
	}


	public int getId_Usario() {
		return id_Usario;
	}


	public void setId_Usario(int id_Usario) {
		this.id_Usario = id_Usario;
	}


	public String getNombreUsuario() {
		return nombreUsuario;
	}


	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}


	public String getContrasena() {
		return contrasena;
	}


	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}


	public int getPuntuacion() {
		return puntuacion;
	}


	public void setPuntuacion(int puntuacion) {
		this.puntuacion = puntuacion;
	}
	
	@Override
	public String toString() {
		return "Usuario [id_Usario=" + id_Usario + ", nombreUsuario=" + nombreUsuario + ", contrasena=" + contrasena
				+ ", puntuacion=" + puntuacion + "]";
	}
	
	public void incrementarPuntuacion(int puntos) {
        puntuacion += puntos;
    }
	
	
	
	
	
}
