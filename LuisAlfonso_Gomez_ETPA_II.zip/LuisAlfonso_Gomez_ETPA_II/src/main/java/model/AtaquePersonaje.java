package model;

public class AtaquePersonaje extends Ataque{

	private String tipoAtaquePersonaje;
	
	public AtaquePersonaje (String nombre, int danio, String tipoAtaquePersonaje) {
		super(nombre,danio);
		this.tipoAtaquePersonaje = tipoAtaquePersonaje;
	}
	
	public String getTipoAtaquePersonaje () {
		
		return tipoAtaquePersonaje;
	}
	
	public void setTipoAtaquePersonaje (String tipoAtaquePersonaje) {
		this.tipoAtaquePersonaje = tipoAtaquePersonaje;
	}
	
	
}
