package model;

public class Finales {

	    public static void mostrarFinal(Personaje personaje, int puzzles, int combates) {
	        System.out.println("\n=== FINAL DE LA AVENTURA DE " + personaje.getNombre().toUpperCase() + " ===");

	        if (puzzles == 2 && combates == 2) {
	            System.out.println("Final BUENO: Has salvado el océano y serás recordado como un héroe.");
	        } else if (puzzles >= 1 || combates >= 1) {
	            System.out.println("Final REGULAR: Lograste sobrevivir, pero tu misión quedó incompleta.");
	        } else {
	            System.out.println("Final MALO: El océano ha sido invadido y fracasaste en protegerlo...");
	        }
	    }
	

}
