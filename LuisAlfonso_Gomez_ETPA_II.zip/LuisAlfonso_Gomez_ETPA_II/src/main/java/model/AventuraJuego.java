package model;

import java.util.*;
import model.*;
import dao.*;


public class AventuraJuego {

	    private Scanner scanner = new Scanner(System.in);
	    private Usuario usuario;
	    private DaoUsuario daoUsuario;

	    public AventuraJuego() {
	        try {
	            daoUsuario = new DaoUsuario();
	        } catch (Exception e) {
	            System.out.println("Error al conectar con la base de datos.");
	        }
	    }

	    public void mostrarJuego() {
	        boolean salir = false;
	        while (!salir) {
	            System.out.println("\n=== MENÚ PRINCIPAL ===");
	            System.out.println("1. Iniciar sesión");
	            System.out.println("2. Ver información de personajes");
	            System.out.println("3. Ver top de jugadores");
	            System.out.println("4. Salir");
	            System.out.print("Seleccione una opción: ");
	            String opcion = scanner.nextLine();

	            switch (opcion) {
	                case "1":
	                    iniciarSesion();
	                    if (usuario != null) {
	                        jugarAventura();
	                    }
	                    break;
	                case "2":
	                    mostrarInformacionPersonajes();
	                    break;
	                case "3":
	                    
	                    break;
	                case "4":
	                    salir = true;
	                    System.out.println("Gracias por jugar. ¡Hasta la próxima!");
	                    break;
	                default:
	                    System.out.println("Opción no válida.");
	            }
	        }
	    }

	    private void iniciarSesion() {
	        try {
	            System.out.print("Nombre de usuario: ");
	            String nombre = scanner.nextLine();
	            Usuario existente = daoUsuario.buscarPorNombre(nombre);

	            if (existente != null) {
	                System.out.print("Contraseña: ");
	                String contrasena = scanner.nextLine();
	                if (contrasena.equals(existente.getContrasena())) {
	                    usuario = existente;
	                    System.out.println("¡Bienvenido de nuevo, " + nombre + "!");
	                } else {
	                    System.out.println("Contraseña incorrecta.");
	                }
	            } else {
	                System.out.println("Usuario no encontrado. Vamos a crearlo.");
	                System.out.print("Elige una contraseña: ");
	                String nuevaContrasena = scanner.nextLine();
	                Usuario nuevo = new Usuario(0, nombre, nuevaContrasena, 0);
	                daoUsuario.CrearUsuario(nuevo);
	                usuario = daoUsuario.buscarPorNombre(nombre);
	                System.out.println("Usuario creado correctamente.");
	            }
	        } catch (Exception e) {
	            System.out.println("Error al iniciar sesión.");
	        }
	    }

	    private void mostrarInformacionPersonajes() {
	        System.out.println("\n=== Personajes ===");
	        System.out.println("1. Michael Phelps - Nadador legendario que busca la fuente de la juventud en aguas profundas.");
	        System.out.println("2. Emily Callahan - Bióloga marina experta en ecosistemas de arrecifes de coral.");
	        System.out.println("3. Jacques Cousteau - Explorador y pionero del buceo con misterios por descubrir.");
	    }


	    private void jugarAventura() {
	        System.out.println("\nElige un personaje:");
	        System.out.println("1. Michael Phelps");
	        System.out.println("2. Emily Callahan");
	        System.out.println("3. Jacques Cousteau");
	        System.out.print("Opción: ");
	        String opcion = scanner.nextLine();

	        Personaje personaje;

	        switch (opcion) {
	            case "1":
	                personaje = new Personaje("Michael Phelps", 100, 100);
	                break;
	            case "2":
	                personaje = new Personaje("Emily Callahan", 100, 100);
	                break;
	            case "3":
	                personaje = new Personaje("Jacques Cousteau", 100, 100);
	                break;
	            default:
	                System.out.println("Opción inválida. Se seleccionará Michael por defecto.");
	                personaje = new Personaje("Michael Phelps", 100, 100);
	        }

	        int puzzles = MiniGames.ejecutarPuzzles(personaje);
	        int combates = Combate.ejecutarCombates(personaje);

	        int puntosGanados = (puzzles + combates) * 100;
	        usuario.incrementarPuntuacion(puntosGanados);

	        try {
	            daoUsuario.actualizarPuntuacion(usuario);
	        } catch (Exception e) {
	            System.out.println("Error al actualizar puntuación.");
	        }

	        Finales.mostrarFinal(personaje, puzzles, combates);
	    }
	}



