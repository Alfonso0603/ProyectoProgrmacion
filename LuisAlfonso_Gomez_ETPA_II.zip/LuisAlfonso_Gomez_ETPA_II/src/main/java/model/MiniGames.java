package model;

import java.util.Scanner;

public class MiniGames {
	
	private static Scanner scanner = new Scanner(System.in);

    public static int ejecutarPuzzles(Personaje personaje) {
        int puzzlesResueltos = 0;

        System.out.println("\nResuelve los siguientes acertijos:");

        if (personaje.getNombre().equalsIgnoreCase("Michael Phelps")) {
            if (preguntar("¿Cuál es el récord de 100m libres?", "46.91")) puzzlesResueltos++;
            if (preguntar("¿Qué músculo impulsa al nadador?", "tríceps")) puzzlesResueltos++;
        } else if (personaje.getNombre().equalsIgnoreCase("Emily Callahan")) {
            if (preguntar("¿Qué protege una barrera de coral?", "ecosistema")) puzzlesResueltos++;
            if (preguntar("¿Qué produce oxígeno en el océano?", "fitoplancton")) puzzlesResueltos++;
        } else if (personaje.getNombre().equalsIgnoreCase("Jacques Cousteau")) {
            if (preguntar("¿Quién inventó el Aqua-Lung?", "Cousteau")) puzzlesResueltos++;
            if (preguntar("¿Qué gas se usa para buceo profundo?", "helio")) puzzlesResueltos++;
        }

        personaje.setVida(Math.min(personaje.getVida() + puzzlesResueltos * 10, personaje.getVidaMaxima()));
        return puzzlesResueltos;
    }

    private static boolean preguntar(String pregunta, String respuestaCorrecta) {
        System.out.println(pregunta);
        String respuesta = scanner.nextLine().trim().toLowerCase();
        return respuesta.equals(respuestaCorrecta.toLowerCase());
    }
}


