package model;

public class AtaqueEnemigo extends Ataque{
	
		private String tipoAtaqueEnemigo;
		
		public AtaqueEnemigo (String nombre, int danio, String tipoAtaqueEnemigo) {
			super(nombre,danio);
			this.tipoAtaqueEnemigo = tipoAtaqueEnemigo;
		}
		
		
		public String getTipoAtaqueEnemigo () {
			return tipoAtaqueEnemigo;
		}
		
		public void setTipoAtaqueEnemigo (String tipoAtaqueEnemigo) {
			this.tipoAtaqueEnemigo = tipoAtaqueEnemigo;
		}


		@Override
		public String toString() {
			return "AtaqueEnemigo [tipoAtaqueEnemigo=" + tipoAtaqueEnemigo + "]";
		}
		
	
		
}
