package dao;

import java.sql.*;

import model.*;

public class DaoUsuario {
	
	private Connection conn = null;
	
	public DaoUsuario () throws SQLException{
		conn = DbConnection.getConnection();
	}
	
	public void CrearUsuario(Usuario usuario) throws SQLException {
		String insertSql = "INSERT INTO jugadores (usuario, contrasena, puntuacion) VALUES (?, ?, ?)";

	    try (Connection conn = DbConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(insertSql)) {

	        ps.setString(1, usuario.getNombreUsuario());
	        ps.setString(2, usuario.getContrasena());
	        ps.setInt(3, usuario.getPuntuacion());

	        int recordsInserted = ps.executeUpdate();

	        if (recordsInserted > 0) {
	            System.out.println("Usuario creado correctamente.");
	        } else {
	            System.out.println("No se pudo crear el usuario.");
	        }

	    } catch (SQLException e) {
	        System.err.println("Error de base de datos al crear usuario: " + e.getMessage());
	    }
	}

	public Usuario LeerUsuario(String nombreUsuario) throws SQLException {
		String selectSql = "SELECT usuario, contrasena, puntuacion FROM jugadores WHERE usuario = ?";

	    Usuario usuario = null;

	    try (Connection conn = DbConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(selectSql)) {

	        ps.setString(1, nombreUsuario);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            usuario = new Usuario();
	            usuario.setNombreUsuario(rs.getString("usuario")); // OJO: el campo se llama "usuario" en la tabla
	            usuario.setContrasena(rs.getString("contrasena"));
	            usuario.setPuntuacion(rs.getInt("puntuacion"));
	            System.out.println("Usuario '" + nombreUsuario + "' encontrado correctamente.");
	        } else {
	            System.out.println("Usuario '" + nombreUsuario + "' no encontrado.");
	        }

	    } catch (SQLException e) {
	        System.err.println("Error de base de datos al leer usuario: " + e.getMessage());
	    }

	    return usuario;
	}

	
	
	public void delete (String nombreUsuario) throws SQLException{
		String deleteSql = "DELETE FROM jugadores WHERE nombre=?";
		
		PreparedStatement statementDelete = conn.prepareStatement(deleteSql);
		
		statementDelete.setString(1, nombreUsuario);
		
		int deleteUsuario = statementDelete.executeUpdate();
		
		if(deleteUsuario > 0) {
			System.out.println("Usuario borrado correctamente");
		}else {
			System.out.println("El usuario no fue borrado correctamente");
		}
		
		statementDelete.close();
		
	}
	
	public Usuario buscarPorNombre(String nombreUsuario) throws SQLException {
	    String query = "SELECT * FROM jugadores WHERE nombreUsuario = ?";

	    try (PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setString(1, nombreUsuario);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            return new Usuario(
	                rs.getInt("id_Usario"),
	                rs.getString("nombreUsuario"),
	                rs.getString("contrasena"),
	                rs.getInt("puntuacion")
	            );
	        }
	    } catch (SQLException e) {
	        System.err.println("Error al buscar usuario: " + e.getMessage());
	    }

	    return null;
	}

	
	public void mostrarTopJugadores() throws SQLException {
	    String query = "SELECT nombreUsuario, puntuacion FROM jugadores ORDER BY puntuacion DESC LIMIT 5";

	    try (PreparedStatement ps = conn.prepareStatement(query);
	         ResultSet rs = ps.executeQuery()) {

	        System.out.println("\n=== TOP JUGADORES ===");

	        int posicion = 1;
	        while (rs.next()) {
	            String nombre = rs.getString("nombreUsuario");
	            int puntuacion = rs.getInt("puntuacion");

	            System.out.println(posicion + ". " + nombre + " - " + puntuacion + " puntos");
	            posicion++;
	        }

	    } catch (SQLException e) {
	        System.err.println("Error al obtener el top de jugadores: " + e.getMessage());
	    }
	}
	
	public void actualizarPuntuacion(Usuario usuario) throws SQLException {
	    String update = "UPDATE jugadores SET puntuacion = ? WHERE id_Usario = ?";
	    
	    try (PreparedStatement ps = conn.prepareStatement(update)) {
	        ps.setInt(1, usuario.getPuntuacion());
	        ps.setInt(2, usuario.getId_Usario());
	        ps.executeUpdate();
	        System.out.println("Puntuación actualizada: " + usuario.getPuntuacion());
	    } catch (SQLException e) {
	        System.err.println("Error al actualizar puntuación: " + e.getMessage());
	    }
	}


	
	

}
